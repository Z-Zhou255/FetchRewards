package com.app.fetchrewards.utils

object Constants {
    const val BASE_URL = "https://fetch-hiring.s3.amazonaws.com/"
}