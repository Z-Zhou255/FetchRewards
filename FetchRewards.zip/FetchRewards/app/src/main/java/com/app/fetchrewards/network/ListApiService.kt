package com.app.fetchrewards.network

import com.app.fetchrewards.model.Item
import retrofit2.http.GET

interface ListApiService {
    @GET("hiring.json")
    suspend fun fetchListRewards(): List<Item>
}